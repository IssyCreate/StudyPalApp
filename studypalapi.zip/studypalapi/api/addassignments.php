<?php
include "db.php";

$title = $_POST['title'] ?? '';
$subject = $_POST['subject'] ?? '';
$instructions = $_POST['instructions'] ?? '';
$due_date = $_POST['due_date'] ?? '';
$due_time = $_POST['due_time'] ?? '';
$user_id = $_POST['user_id'] ?? '';

if (
    empty($title) ||
    empty($subject) ||
    empty($due_date) ||
    empty($due_time) ||
    empty($user_id)
) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing required fields"
    ]);

    exit();
}

$sql = "INSERT INTO assignments (title, subject, instructions, due_date, due_time, user_id) VALUES
('$title', '$subject', '$instructions',
 '$due_date', '$due_time', '$user_id')
";

if ($conn->query($sql)) {

    echo json_encode([
        "status" => "success"
    ]);

} else {

    echo json_encode([
        "status" => "error",
        "message" => $conn->error
    ]);
}?>