<?php

include "db.php";

header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"));

if (!$data) {

    echo json_encode([
        "status" => "error",
        "message" => "No input data received"
    ]);

    exit;
}

$user_id = $data->user_id ?? '';
$subject = $data->subject ?? '';
$content = $data->content ?? '';

if (
    empty($user_id) ||
    empty($subject) ||
    empty($content)
) {

    echo json_encode([
        "status" => "error",
        "message" => "Missing fields"
    ]);

    exit;
}

$sql = "INSERT INTO notes
(user_id, subject, content)

VALUES
('$user_id', '$subject', '$content')";

if ($conn->query($sql)) {

    echo json_encode([
        "status" => "success"
    ]);

} else {

    echo json_encode([
        "status" => "error",
        "message" => $conn->error
    ]);
}
?>