<?php
include "db.php";

// Get POST data (from MAUI FormUrlEncodedContent)
$name = $conn->real_escape_string($_POST['name'] ?? '');
$email = $conn->real_escape_string($_POST['email'] ?? '') ;
$password = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT );
$age = intval($_POST['age'] ?? '');

// Check if user exists
$check = $conn->query("SELECT * FROM user WHERE email='$email'");

if ($check->num_rows > 0) {
    echo "error";
    exit;
}

// Insert user (FIXED)
$sql = "INSERT INTO user (name, email, password, age) 
        VALUES ('$name', '$email', '$password', '$age')";

if ($conn->query($sql)) {
    echo "success";
} else {
    echo "error";
}
?>