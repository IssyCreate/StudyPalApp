<?php

include "db.php";

$user_id = $_GET['user_id'] ?? '';

if (empty($user_id)) {
    echo json_encode([]);
    exit();
}

$sql = "SELECT
    id,
    title,
    subject,
    instructions,
    due_date,
    due_time
FROM assignments
WHERE user_id = '$user_id'
ORDER BY due_date ASC, due_time ASC
";

$result = $conn->query($sql);

$assignments = [];

while ($row = $result->fetch_assoc()) {
    $assignments[] = $row;
}

echo json_encode($assignments);

?>