<?php

header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "studypal");

$data = json_decode(file_get_contents("php://input"));

$user_id = $data->user_id ?? 0;
$score = $data->score ?? 0;

$sql = "INSERT INTO quiz_results(user_id, score)
VALUES('$user_id','$score')
";

if ($conn->query($sql)) {

    echo json_encode([
        "status" => "success"
    ]);

} else {

    echo json_encode([
        "status" => "error"
    ]);
}
?>