<?php
header("Content-Type: application/json");
include "db.php";

$user_id = $_GET['user_id'] ?? 0;

$sql = "SELECT SUM(duration_minutes) as total
        FROM study_sessions
        WHERE user_id = '$user_id'";

$result = $conn->query($sql);
$row = $result->fetch_assoc();

echo json_encode([
    "total" => (int)$row["total"]
]);

exit();
?>