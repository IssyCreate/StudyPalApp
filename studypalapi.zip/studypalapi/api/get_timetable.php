<?php
include "db.php";
header("Content-Type: application/json");

$user_id = $_GET['user_id'] ?? 0;

$sql = "SELECT Subject, Time, DurationMinutes, Day
        FROM timetable
        WHERE user_id = '$user_id'
        ORDER BY Day";

$result = $conn->query($sql);

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = [
        "Subject" => $row["Subject"],
        "Time" => $row["Time"],
        "DurationMinutes" => (int)$row["DurationMinutes"],
        "Day" => $row["Day"]
    ];
}

echo json_encode($data);?>    