<?php
include "db.php";

$sql = "SELECT id, question, option1, option2, option3, option4, correct_answer FROM quizzes";
$result = $conn->query($sql);

$data = [];

while($row = $result->fetch_assoc()) {
    $row['id'] = (int)$row['id']; 
    $data[] = $row;
}

echo json_encode($data);
?>