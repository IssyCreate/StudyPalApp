<?php

include "db.php";
header("Content-Type: application/json");

$user_id = $_GET['user_id'] ?? 0;

$sql = "SELECT
id,
subject,
content,
created_at
FROM notes
WHERE user_id = '$user_id'
ORDER BY created_at DESC";

$result = $conn->query($sql);

$notes = [];

while ($row = $result->fetch_assoc()) {

    $notes[] = [
        "id" => (int)$row["id"],
        "subject" => $row["subject"],
        "content" => $row["content"],
        "created_at" => $row["created_at"]
    ];
}

echo json_encode($notes);
exit();
?>