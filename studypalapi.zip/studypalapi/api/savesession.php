<?php
include "db.php";
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"));

$user_id = $data->user_id ?? null;
$subject = $data->subject ?? null;
$duration = $data->duration_minutes ?? null;

if (!$user_id || !$subject || !$duration) {
    echo json_encode(["status" => "error", "message" => "Missing data"]);
    exit;
}

$sql = "INSERT INTO study_sessions (user_id, subject, duration_minutes)
        VALUES ('$user_id', '$subject', '$duration')";

if ($conn->query($sql)) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => $conn->error]);
}
?>