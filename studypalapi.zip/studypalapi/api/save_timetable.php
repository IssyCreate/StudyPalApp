<?php

include "db.php";
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"));

$user_id = $data->user_id ?? null;
$subject = $data->subject ?? null;
$start_time = $data->start_time ?? null;
$duration_minutes = $data->duration_minutes ?? null;
$day = $data->day ?? null;

if (
    !$user_id ||
    !$subject ||
    !$start_time ||
    !$duration_minutes ||
    !$day
) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing data"
    ]);

    exit;
}

$sql = "INSERT INTO timetable
(user_id, Subject, Time, DurationMinutes, Day)

VALUES
('$user_id', '$subject', '$start_time',
 '$duration_minutes', '$day')";

if ($conn->query($sql)) {

    echo json_encode([
        "status" => "success"
    ]);

} else {

    echo json_encode([
        "status" => "error",
        "message" => $conn->error
    ]);
}
?>