<?php
include "db.php";

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if ($email == '' || $password == '') {
    echo json_encode([
        "status" => "fail",
        "message" => "Missing fields"
    ]);
    exit;
}

// check user
$result = $conn->query("SELECT * FROM user WHERE email='$email'");

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    if (password_verify($password, $row['password'])) {
        echo json_encode([   
    "status" => "success",
    "id" => (int)$row["UserID"],
    "name" => $row["name"]
        ]);
    } else {
        echo json_encode([
            "status" => "fail",
            "message" => "Wrong password"
        ]);
    }
} else {
    echo json_encode([
        "status" => "fail",
        "message" => "User not found"
    ]);
}
?>